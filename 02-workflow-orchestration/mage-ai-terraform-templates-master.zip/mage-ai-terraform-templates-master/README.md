# mage-ai-terraform-templates
Terraform templates for deploying mage-ai to AWS, GCP and Azure
